import os
from glob import glob
from setuptools import setup

package_name = 'kurox_gazebo'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name), glob('launch/*.launch.py')),
        (os.path.join('share/' + package_name + '/models/kurox/meshes'), glob('models/kurox/meshes/*.dae')),
        (os.path.join('share/' + package_name + '/models/kurox_world'), glob('models/kurox_world/*.sdf')),
        (os.path.join('share/' + package_name + '/worlds/kurox_empty'), glob('worlds/kurox_empty/*.model')),
        (os.path.join('share/' + package_name + '/worlds/kurox_worlds'), glob('worlds/kurox_worlds/*.model')),
               
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='TESR',
    maintainer_email='tesrshop@gmail.com',
    description='TESR kurox Gazebo',
    license='TESR',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
        ],
    },
)
