#!/usr/bin/env python3

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node  #added for run ekf

def generate_launch_description():
    use_sim_time = LaunchConfiguration('use_sim_time', default='True')
    pkg_gazebo_ros = get_package_share_directory('gazebo_ros')
    
    launch_file_dir = os.path.join(get_package_share_directory('kurox_gazebo'))

    world_file_name = 'kurox_worlds/kurox.model'
    world = os.path.join(get_package_share_directory('kurox_gazebo'),
                         'worlds', world_file_name)
    
    ros2_laser_scan_merger_launch_file_dir = os.path.join(get_package_share_directory('ros2_laser_scan_merger'), 'launch')
    pointcloud_to_laserscan_launch_file_dir = os.path.join(get_package_share_directory('pointcloud_to_laserscan'), 'launch')

    return LaunchDescription([
        
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(pkg_gazebo_ros, 'launch', 'gzserver.launch.py')
            ),
            launch_arguments={'world': world}.items(),
        ),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(pkg_gazebo_ros, 'launch', 'gzclient.launch.py')
            ),
        ),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([ros2_laser_scan_merger_launch_file_dir, '/sim_merge_2_scan.launch.py']),
            launch_arguments={ 'use_sim_time': use_sim_time,}.items(),
            
        ),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([pointcloud_to_laserscan_launch_file_dir, '/sample_pointcloud_to_laserscan_launch.py']),
            launch_arguments={ 'use_sim_time': use_sim_time,}.items(),
        ),


        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([launch_file_dir, '/kurox_robot_state_publisher_sim.launch.py']),
            launch_arguments={'use_sim_time': use_sim_time}.items(),
        ),

    ])
